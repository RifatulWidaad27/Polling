<?php
require $_SERVER['APP_DIR'] . '/application/app.php';