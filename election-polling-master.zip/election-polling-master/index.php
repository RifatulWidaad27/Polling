<?php
require_once __DIR__ . '/application/bootstrap.php';

$app->run();